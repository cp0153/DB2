<?php
   
   echo 'hello world!';

?>
